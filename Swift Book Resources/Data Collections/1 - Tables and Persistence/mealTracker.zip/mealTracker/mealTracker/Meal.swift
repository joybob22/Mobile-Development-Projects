//
//  Meal.swift
//  mealTracker
//
//  Created by Brayden Lemke on 10/11/21.
//

import Foundation

struct Meal {
    var name: String
    var food: [Food]
}
