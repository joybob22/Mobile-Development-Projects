//
//  NobelPrizeWinner.swift
//  apiProject
//
//  Created by Brayden Lemke on 11/29/21.
//

import Foundation


struct NobelPrizeWinner: Codable {
    var id: String
    var firstname: String
    var surname: String
    var motivation: String
}
