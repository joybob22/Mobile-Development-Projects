//
//  RepInfo.swift
//  apiProject
//
//  Created by Brayden Lemke on 11/16/21.
//

import Foundation

struct RepInfo: Codable {
    var name: String
    var party: String
    var link: String
}
