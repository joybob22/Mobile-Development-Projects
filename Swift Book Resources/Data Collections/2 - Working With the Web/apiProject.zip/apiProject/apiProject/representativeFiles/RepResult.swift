//
//  RepResult.swift
//  apiProject
//
//  Created by Brayden Lemke on 11/16/21.
//

import Foundation

struct RepResult: Codable {
    var results: [RepInfo]
}
